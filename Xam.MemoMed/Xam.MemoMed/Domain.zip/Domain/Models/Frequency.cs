﻿namespace Xam.MemoMed.Domain.Models
{
    public class Frequency
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
